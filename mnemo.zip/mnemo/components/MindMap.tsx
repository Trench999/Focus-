type N = { id: string; label: string };
type E = { from: string; to: string };

export default function MindMap({ nodes, edges }: { nodes: N[]; edges: E[] }) {
  if (!nodes?.length) return <p className="text-slate-500">No mind map for this deck.</p>;
  const pos = new Map<string, { x: number; y: number }>();
  nodes.forEach((n, i) => {
    if (i === 0) return pos.set(n.id, { x: 200, y: 200 });
    const a = ((i - 1) / (nodes.length - 1)) * 2 * Math.PI;
    pos.set(n.id, { x: 200 + 150 * Math.cos(a), y: 200 + 150 * Math.sin(a) });
  });
  const short = (s: string) => (s.length > 18 ? s.slice(0, 17) + "…" : s);
  return (
    <svg viewBox="0 0 400 400" className="w-full rounded-xl border bg-white">
      {edges.map((e, i) => {
        const a = pos.get(e.from), b = pos.get(e.to);
        return a && b ? <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="#cbd5e1" /> : null;
      })}
      {nodes.map((n, i) => {
        const p = pos.get(n.id)!;
        return (
          <g key={n.id}>
            <circle cx={p.x} cy={p.y} r={i === 0 ? 9 : 6} fill={i === 0 ? "#4f46e5" : "#818cf8"} />
            <text x={p.x} y={p.y + (i === 0 ? 22 : 18)} fontSize="9" textAnchor="middle" fill="#334155">{short(n.label)}</text>
          </g>
        );
      })}
    </svg>
  );
}
