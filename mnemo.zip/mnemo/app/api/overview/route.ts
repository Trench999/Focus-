import { NextResponse } from "next/server";
import { withUser } from "@/lib/db";
import { getUserId } from "@/lib/auth";

export async function GET() {
  const userId = await getUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const data = await withUser(userId, async (c) => {
    const u = (await c.query("select streak_count from users where id=$1", [userId])).rows[0];
    const decks = (await c.query(
      `select d.id, d.title, count(c.id)::int cards, (count(c.id) filter (where c.due <= now()))::int due
       from decks d left join cards c on c.deck_id = d.id group by d.id order by d.created_at desc`
    )).rows;
    const week = (await c.query(
      `select to_char(reviewed_at::date,'MM-DD') day, count(*)::int n from reviews
       where reviewed_at > now() - interval '7 days' group by 1 order by 1`
    )).rows;
    const total = (await c.query("select count(*)::int n from reviews")).rows[0].n;
    return { streak: u.streak_count, decks, week, total };
  });
  return NextResponse.json(data);
}
