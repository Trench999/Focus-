import { NextResponse } from "next/server";
import { z } from "zod";
import { getUserId } from "@/lib/auth";
import { createDeck, HttpError } from "@/lib/generate";
import { pdfToText, urlToText } from "@/lib/extract";

export const runtime = "nodejs";
const MAX_PDF = 10 * 1024 * 1024;
const Title = z.string().trim().min(1).max(120);

export async function POST(req: Request) {
  const userId = await getUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    if ((req.headers.get("content-type") ?? "").startsWith("multipart/form-data")) {
      const form = await req.formData();
      const file = form.get("file");
      const title = Title.safeParse(form.get("title"));
      if (!(file instanceof File) || !title.success) throw new HttpError(400, "Invalid input");
      if (file.size > MAX_PDF) throw new HttpError(400, "PDF must be under 10 MB");
      const text = await pdfToText(Buffer.from(await file.arrayBuffer()));
      return NextResponse.json(await createDeck(userId, title.data, text, "pdf"));
    }
    const p = z.object({ url: z.string().url().max(2000), title: Title }).safeParse(await req.json().catch(() => null));
    if (!p.success) throw new HttpError(400, "Invalid input");
    const text = await urlToText(p.data.url);
    return NextResponse.json(await createDeck(userId, p.data.title, text, "link", p.data.url));
  } catch (e) {
    if (e instanceof HttpError) return NextResponse.json({ error: e.message }, { status: e.status });
    throw e;
  }
}
