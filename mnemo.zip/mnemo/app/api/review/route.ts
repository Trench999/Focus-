import { NextResponse } from "next/server";
import { z } from "zod";
import { fsrs, type Card, type Grade } from "ts-fsrs";
import { withUser } from "@/lib/db";
import { getUserId } from "@/lib/auth";

const scheduler = fsrs();

// Daily review queue
export async function GET() {
  const userId = await getUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const cards = await withUser(userId, async (c) =>
    (await c.query("select id, deck_id, kind, front, back, options from cards where due <= now() order by due limit 20")).rows
  );
  return NextResponse.json({ cards });
}

// Submit a rating: 1 Again, 2 Hard, 3 Good, 4 Easy
const Body = z.object({ cardId: z.string().uuid(), rating: z.number().int().min(1).max(4) });

export async function POST(req: Request) {
  const userId = await getUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });

  const result = await withUser(userId, async (c) => {
    const row = (await c.query("select * from cards where id=$1", [p.data.cardId])).rows[0]; // RLS-scoped
    if (!row) return null;
    const card: Card = {
      due: row.due, stability: row.stability, difficulty: row.difficulty,
      elapsed_days: row.elapsed_days, scheduled_days: row.scheduled_days,
      reps: row.reps, lapses: row.lapses, state: row.state,
      last_review: row.last_review ?? undefined, learning_steps: 0,
    };
    const { card: n, log } = scheduler.next(card, new Date(), p.data.rating as Grade);
    await c.query(
      `update cards set due=$2, stability=$3, difficulty=$4, elapsed_days=$5, scheduled_days=$6,
       reps=$7, lapses=$8, state=$9, last_review=$10 where id=$1`,
      [row.id, n.due, n.stability, n.difficulty, n.elapsed_days, n.scheduled_days, n.reps, n.lapses, n.state, n.last_review]
    );
    await c.query(
      `insert into reviews (user_id,card_id,rating,state,due,stability,difficulty,elapsed_days,scheduled_days)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [userId, row.id, p.data.rating, log.state, n.due, n.stability, n.difficulty, n.elapsed_days, n.scheduled_days]
    );
    await c.query(
      `update users set
         streak_count = case when last_review_date = current_date then streak_count
                             when last_review_date = current_date - 1 then streak_count + 1
                             else 1 end,
         last_review_date = current_date
       where id = $1`,
      [userId]
    );
    return { nextDue: n.due };
  });
  if (!result) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(result);
}
