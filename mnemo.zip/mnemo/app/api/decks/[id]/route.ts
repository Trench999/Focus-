import { NextResponse } from "next/server";
import { z } from "zod";
import { withUser } from "@/lib/db";
import { getUserId } from "@/lib/auth";

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = await getUserId();
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const id = z.string().uuid().safeParse((await params).id);
  if (!id.success) return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  const row = await withUser(userId, async (c) =>
    (await c.query("select title, mind_map from documents where deck_id=$1 order by created_at desc limit 1", [id.data])).rows[0]
  );
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(row);
}
