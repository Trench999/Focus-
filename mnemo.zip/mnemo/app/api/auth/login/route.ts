import { NextResponse } from "next/server";
import { z } from "zod";
import { admin } from "@/lib/db";
import { createSession, logAttempt, tooManyAttempts, verifyPassword } from "@/lib/auth";

const Body = z.object({ username: z.string().min(1).max(24), password: z.string().min(1).max(128) });

export async function POST(req: Request) {
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return NextResponse.json({ error: "Invalid credentials" }, { status: 400 });
  const username = p.data.username;
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0].trim() || null;

  if (await tooManyAttempts(username, ip))
    return NextResponse.json({ error: "Too many attempts, try again later" }, { status: 429 });

  const r = await admin.query("select id, password_hash from users where username=$1", [username]);
  const ok = r.rows[0] && (await verifyPassword(r.rows[0].password_hash, p.data.password));
  await logAttempt(username, ip, !!ok);
  if (!ok) return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });

  await createSession(r.rows[0].id);
  return NextResponse.json({ ok: true });
}
