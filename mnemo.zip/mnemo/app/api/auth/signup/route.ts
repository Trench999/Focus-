import { NextResponse } from "next/server";
import { z } from "zod";
import { admin } from "@/lib/db";
import { createSession, hashPassword } from "@/lib/auth";

const Body = z.object({
  username: z.string().regex(/^[A-Za-z0-9_]{3,24}$/),
  password: z.string().min(10).max(128),
});

export async function POST(req: Request) {
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success)
    return NextResponse.json({ error: "Username: 3-24 letters, numbers or underscores. Password: min 10 characters." }, { status: 400 });
  try {
    const r = await admin.query(
      "insert into users (username, password_hash) values ($1,$2) returning id",
      [p.data.username, await hashPassword(p.data.password)]
    );
    await createSession(r.rows[0].id);
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    if (e.code === "23505") return NextResponse.json({ error: "That username is taken" }, { status: 400 });
    throw e;
  }
}
