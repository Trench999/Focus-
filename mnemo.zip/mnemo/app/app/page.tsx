"use client";
import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import MindMap from "@/components/MindMap";

type Card = { id: string; kind: "flashcard" | "quiz"; front: string; back: string; options?: string[] };
const RATINGS = [["Again", 1], ["Hard", 2], ["Good", 3], ["Easy", 4]] as const;
const json = { "content-type": "application/json" };

export default function Dashboard() {
  const router = useRouter();
  const [cards, setCards] = useState<Card[]>([]);
  const [i, setI] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");
  const [mode, setMode] = useState<"text" | "pdf" | "link">("text");
  const [url, setUrl] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [ov, setOv] = useState<any>(null);
  const [map, setMap] = useState<any>(null);

  const load = useCallback(async () => {
    const res = await fetch("/api/review");
    if (res.status === 401) return router.push("/");
    setCards((await res.json()).cards);
    setI(0);
    setRevealed(false);
    fetch("/api/overview").then((r) => (r.ok ? r.json() : null)).then(setOv);
    setLoaded(true);
  }, [router]);

  useEffect(() => { load(); }, [load]);

  async function rate(rating: number) {
    await fetch("/api/review", { method: "POST", headers: json, body: JSON.stringify({ cardId: cards[i].id, rating }) });
    setRevealed(false);
    setI(i + 1);
  }

  async function generate(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg("Generating… this can take up to a minute.");
    let res: Response;
    if (mode === "text") res = await fetch("/api/generate", { method: "POST", headers: json, body: JSON.stringify({ title, text }) });
    else if (mode === "pdf") {
      const fd = new FormData();
      fd.append("file", file!);
      fd.append("title", title);
      res = await fetch("/api/ingest", { method: "POST", body: fd });
    } else res = await fetch("/api/ingest", { method: "POST", headers: json, body: JSON.stringify({ url, title }) });
    const d = await res.json().catch(() => ({}));
    if (res.ok) {
      setMsg(`Created ${d.cards} flashcards and ${d.quiz} quiz questions.`);
      setTitle("");
      setText("");
      setUrl("");
      setFile(null);
      await load();
    } else setMsg(d.error ?? "Something went wrong");
    setBusy(false);
  }

  async function openDeck(id: string) {
    const res = await fetch(`/api/decks/${id}`);
    setMap(res.ok ? await res.json() : null);
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
  }

  const card = cards[i];

  return (
    <main className="mx-auto max-w-2xl space-y-8 p-6">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Mnemo</h1>
        <button onClick={logout} className="text-sm text-slate-600">Log out</button>
      </header>

      {ov && (
        <section className="space-y-3">
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="rounded-xl border bg-white p-3"><div className="text-2xl font-bold">{ov.streak}</div><div className="text-xs text-slate-500">day streak</div></div>
            <div className="rounded-xl border bg-white p-3"><div className="text-2xl font-bold">{ov.total}</div><div className="text-xs text-slate-500">reviews</div></div>
            <div className="rounded-xl border bg-white p-3"><div className="text-2xl font-bold">{ov.week.reduce((a: number, d: any) => a + d.n, 0)}</div><div className="text-xs text-slate-500">last 7 days</div></div>
          </div>
          {ov.decks.length > 0 && (
            <ul className="divide-y rounded-xl border bg-white">
              {ov.decks.map((d: any) => (
                <li key={d.id}>
                  <button onClick={() => openDeck(d.id)} className="flex w-full items-center justify-between p-3 text-left hover:bg-slate-50">
                    <span>{d.title}</span>
                    <span className="text-sm text-slate-500">{d.cards} cards · {d.due} due</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
          {map && (
            <div className="space-y-2">
              <h3 className="text-sm font-semibold">Mind map: {map.title}</h3>
              <MindMap nodes={map.mind_map?.nodes ?? []} edges={map.mind_map?.edges ?? []} />
            </div>
          )}
        </section>
      )}

      <section className="space-y-3">
        <h2 className="font-semibold">Review {loaded && card ? `(${i + 1}/${cards.length})` : ""}</h2>
        {!loaded ? <p className="text-slate-500">Loading…</p> : !card ? (
          <p className="rounded-xl border bg-white p-6 text-slate-600">Nothing due. Add material below to create cards.</p>
        ) : (
          <div className="space-y-4 rounded-xl border bg-white p-6">
            <p className="text-lg">{card.front}</p>
            {card.kind === "quiz" && card.options && (
              <ul className="list-disc pl-5 text-slate-700">{card.options.map((o) => <li key={o}>{o}</li>)}</ul>
            )}
            {revealed ? (
              <>
                <p className="rounded-lg bg-indigo-50 p-3">{card.back}</p>
                <div className="grid grid-cols-4 gap-2">
                  {RATINGS.map(([label, n]) => (
                    <button key={n} onClick={() => rate(n)} className="rounded-lg border p-2 text-sm hover:bg-slate-100">{label}</button>
                  ))}
                </div>
              </>
            ) : (
              <button onClick={() => setRevealed(true)} className="w-full rounded-lg bg-indigo-600 p-3 text-white">Show answer</button>
            )}
          </div>
        )}
      </section>

      <section className="space-y-3">
        <h2 className="font-semibold">Add material</h2>
        <form onSubmit={generate} className="space-y-3">
          <div className="flex gap-2">
            {(["text", "pdf", "link"] as const).map((m) => (
              <button type="button" key={m} onClick={() => setMode(m)}
                className={`rounded-full border px-4 py-1 text-sm ${mode === m ? "bg-indigo-600 text-white" : "bg-white"}`}>
                {m === "text" ? "Text" : m === "pdf" ? "PDF" : "Link"}
              </button>
            ))}
          </div>
          <input className="w-full rounded-lg border p-3" placeholder="Deck title" value={title}
            onChange={(e) => setTitle(e.target.value)} required maxLength={120} />
          {mode === "text" && (
            <textarea className="h-48 w-full rounded-lg border p-3" placeholder="Paste your notes or article text (50+ characters)"
              value={text} onChange={(e) => setText(e.target.value)} required minLength={50} maxLength={60000} />
          )}
          {mode === "pdf" && (
            <input className="w-full rounded-lg border bg-white p-3" type="file" accept="application/pdf"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)} required />
          )}
          {mode === "link" && (
            <input className="w-full rounded-lg border p-3" type="url" placeholder="https://example.com/article"
              value={url} onChange={(e) => setUrl(e.target.value)} required />
          )}
          <button disabled={busy} className="w-full rounded-lg bg-indigo-600 p-3 font-medium text-white disabled:opacity-50">
            {busy ? "Working…" : "Generate flashcards & quiz"}
          </button>
          {msg && <p className="text-sm text-slate-600">{msg}</p>}
        </form>
      </section>
    </main>
  );
}
