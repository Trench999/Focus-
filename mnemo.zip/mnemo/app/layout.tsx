import "./globals.css";

export const metadata = { title: "Mnemo", description: "Turn anything you read into things you remember." };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
