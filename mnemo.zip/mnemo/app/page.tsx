"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Home() {
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr("");
    const res = await fetch(`/api/auth/${mode}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    if (res.ok) router.push("/app");
    else setErr((await res.json().catch(() => ({}))).error ?? "Something went wrong");
    setBusy(false);
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center gap-6 p-6">
      <div>
        <h1 className="text-3xl font-bold">Mnemo</h1>
        <p className="text-slate-600">Turn anything you read into things you remember.</p>
      </div>
      <form onSubmit={submit} className="flex flex-col gap-3">
        <input className="rounded-lg border p-3" type="text" placeholder="Username" value={username}
          onChange={(e) => setUsername(e.target.value)} required pattern="[A-Za-z0-9_]{3,24}"
          title="3-24 letters, numbers or underscores" autoComplete="username" />
        <input className="rounded-lg border p-3" type="password" placeholder="Password (min 10 characters)" value={password}
          onChange={(e) => setPassword(e.target.value)} required minLength={mode === "signup" ? 10 : 1}
          autoComplete={mode === "signup" ? "new-password" : "current-password"} />
        {err && <p className="text-sm text-red-600">{err}</p>}
        <button disabled={busy} className="rounded-lg bg-indigo-600 p-3 font-medium text-white disabled:opacity-50">
          {busy ? "…" : mode === "login" ? "Log in" : "Create account"}
        </button>
      </form>
      <button className="text-sm text-indigo-600" onClick={() => setMode(mode === "login" ? "signup" : "login")}>
        {mode === "login" ? "New here? Create an account" : "Have an account? Log in"}
      </button>
    </main>
  );
}
