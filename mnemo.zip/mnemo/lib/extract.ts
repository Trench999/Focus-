import dns from "dns/promises";
import net from "net";
import { HttpError } from "./generate";

export async function pdfToText(buf: Buffer) {
  if (buf.subarray(0, 5).toString() !== "%PDF-") throw new HttpError(400, "Not a valid PDF");
  const pdf = (await import("pdf-parse/lib/pdf-parse.js")).default;
  try {
    return (await pdf(buf)).text.replace(/\s+/g, " ").trim();
  } catch {
    throw new HttpError(400, "Could not read that PDF");
  }
}

// ── SSRF protection: only public http(s) hosts, re-checked on every redirect ──
function isPrivate(ip: string): boolean {
  if (ip.startsWith("::ffff:")) return isPrivate(ip.slice(7));
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split(".").map(Number);
    return a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
  }
  const l = ip.toLowerCase();
  return l === "::1" || l === "::" || /^(fc|fd|fe[89ab])/.test(l);
}

async function assertPublic(u: URL) {
  if (!["http:", "https:"].includes(u.protocol)) throw new HttpError(400, "Only http(s) links are supported");
  const addrs = await dns.lookup(u.hostname, { all: true }).catch(() => []);
  if (!addrs.length || addrs.some((a) => isPrivate(a.address))) throw new HttpError(400, "That link isn't allowed");
}

async function readLimited(res: Response, max: number) {
  const reader = res.body!.getReader();
  const chunks: Uint8Array[] = [];
  let n = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    n += value.length;
    if (n > max) { await reader.cancel(); break; }
    chunks.push(value);
  }
  return Buffer.concat(chunks).toString("utf8");
}

const htmlToText = (html: string) =>
  html
    .replace(/<(script|style|nav|footer|header|noscript|svg)[\s\S]*?<\/\1>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/\s+/g, " ").trim();

export async function urlToText(raw: string) {
  let u: URL;
  try { u = new URL(raw); } catch { throw new HttpError(400, "Invalid link"); }
  for (let hop = 0; hop <= 3; hop++) {
    await assertPublic(u);
    const res = await fetch(u, {
      redirect: "manual",
      signal: AbortSignal.timeout(10000),
      headers: { "user-agent": "MnemoBot/1.0" },
    }).catch(() => { throw new HttpError(400, "Could not fetch that link"); });
    const loc = res.headers.get("location");
    if (res.status >= 300 && res.status < 400 && loc) { u = new URL(loc, u); continue; }
    if (!res.ok) throw new HttpError(400, "Could not fetch that link");
    if (!/text\/(html|plain)/.test(res.headers.get("content-type") ?? ""))
      throw new HttpError(400, "Link must be a web page");
    return htmlToText(await readLimited(res, 2_000_000));
  }
  throw new HttpError(400, "Too many redirects");
}
