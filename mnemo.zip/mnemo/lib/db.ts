import { Pool, PoolClient } from "pg";

const app = new Pool({ connectionString: process.env.DATABASE_URL });
export const admin = new Pool({ connectionString: process.env.DATABASE_ADMIN_URL });

// Runs fn in a transaction scoped to one user, so RLS policies apply.
export async function withUser<T>(userId: string, fn: (c: PoolClient) => Promise<T>): Promise<T> {
  const c = await app.connect();
  try {
    await c.query("begin");
    await c.query("select set_config('app.user_id', $1, true)", [userId]);
    const out = await fn(c);
    await c.query("commit");
    return out;
  } catch (e) {
    await c.query("rollback");
    throw e;
  } finally {
    c.release();
  }
}
