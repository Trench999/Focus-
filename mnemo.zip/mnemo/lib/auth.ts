import argon2 from "argon2";
import { createHash, randomBytes } from "crypto";
import { cookies } from "next/headers";
import { admin } from "./db";

const COOKIE = "mnemo_session";
const SESSION_DAYS = 30;
const sha = (s: string) => createHash("sha256").update(s).digest("hex");

export const hashPassword = (pw: string) => argon2.hash(pw, { type: argon2.argon2id });
export const verifyPassword = (hash: string, pw: string) => argon2.verify(hash, pw);

export async function createSession(userId: string) {
  const token = randomBytes(32).toString("hex");
  const expires = new Date(Date.now() + SESSION_DAYS * 864e5);
  await admin.query(
    "insert into sessions (user_id, token_hash, expires_at) values ($1,$2,$3)",
    [userId, sha(token), expires]
  );
  (await cookies()).set(COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    expires,
  });
}

export async function getUserId(): Promise<string | null> {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  const r = await admin.query(
    "select user_id from sessions where token_hash=$1 and expires_at>now()",
    [sha(token)]
  );
  return r.rows[0]?.user_id ?? null;
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  if (token) await admin.query("delete from sessions where token_hash=$1", [sha(token)]);
  jar.delete(COOKIE);
}

// 5 failures per 15 min per username or IP
export async function tooManyAttempts(username: string, ip: string | null) {
  const r = await admin.query(
    `select count(*)::int n from login_attempts
     where succeeded=false and created_at > now() - interval '15 minutes'
       and (username=$1 or ip=$2::inet)`,
    [username, ip]
  );
  return r.rows[0].n >= 5;
}

export const logAttempt = (username: string, ip: string | null, ok: boolean) =>
  admin.query("insert into login_attempts (username, ip, succeeded) values ($1,$2::inet,$3)", [username, ip, ok]);
