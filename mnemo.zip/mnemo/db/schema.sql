-- Mnemo schema (PostgreSQL 15+)
-- Own email+password auth. RLS keys off a per-request setting:
--   SELECT set_config('app.user_id', '<uuid>', true);  -- call inside each transaction
-- Connect the app with a NON-superuser role so RLS is enforced.

create extension if not exists "pgcrypto";
create extension if not exists "citext";

-- Helper: current user from the request context
create or replace function app_user_id() returns uuid
language sql stable as $$
  select nullif(current_setting('app.user_id', true), '')::uuid
$$;

-- ───────── Users & auth ─────────
create table users (
  id uuid primary key default gen_random_uuid(),
  username citext unique not null check (username ~ '^[A-Za-z0-9_]{3,24}$'),
  password_hash text not null,              -- Argon2id, never plain text
  plan text not null default 'free' check (plan in ('free','pro')),
  streak_count int not null default 0,
  last_review_date date,
  created_at timestamptz not null default now()
);

create table sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  token_hash text unique not null,          -- store a hash of the cookie token
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index on sessions (user_id);

create table login_attempts (               -- for rate limiting
  id bigserial primary key,
  username citext not null,
  ip inet,
  succeeded boolean not null,
  created_at timestamptz not null default now()
);
create index on login_attempts (username, created_at desc);
create index on login_attempts (ip, created_at desc);

-- ───────── Content ─────────
create table decks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  title text not null,
  created_at timestamptz not null default now()
);
create index on decks (user_id);

create table documents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  deck_id uuid references decks(id) on delete set null,
  source_type text not null check (source_type in ('text','pdf','link')),
  source_url text,
  title text,
  content text,                             -- extracted text
  mind_map jsonb,                           -- generated nodes/edges
  status text not null default 'pending'
    check (status in ('pending','processing','done','failed')),
  created_at timestamptz not null default now()
);
create index on documents (user_id);

create table cards (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  deck_id uuid not null references decks(id) on delete cascade,
  document_id uuid references documents(id) on delete set null,
  kind text not null default 'flashcard' check (kind in ('flashcard','quiz')),
  front text not null,
  back text not null,
  options jsonb,                            -- quiz choices, if kind = 'quiz'
  -- FSRS-5 state (matches ts-fsrs Card)
  due timestamptz not null default now(),
  stability real not null default 0,
  difficulty real not null default 0,
  elapsed_days int not null default 0,
  scheduled_days int not null default 0,
  reps int not null default 0,
  lapses int not null default 0,
  state smallint not null default 0,        -- 0 New, 1 Learning, 2 Review, 3 Relearning
  last_review timestamptz,
  created_at timestamptz not null default now()
);
create index on cards (user_id, due);       -- daily review queue
create index on cards (deck_id);

create table reviews (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  card_id uuid not null references cards(id) on delete cascade,
  rating smallint not null check (rating between 1 and 4),  -- Again/Hard/Good/Easy
  state smallint not null,
  due timestamptz not null,
  stability real not null,
  difficulty real not null,
  elapsed_days int not null,
  scheduled_days int not null,
  reviewed_at timestamptz not null default now()
);
create index on reviews (user_id, reviewed_at desc);
create index on reviews (card_id);

-- ───────── Row-level security ─────────
alter table users     enable row level security;
alter table decks     enable row level security;
alter table documents enable row level security;
alter table cards     enable row level security;
alter table reviews   enable row level security;

alter table users     force row level security;
alter table decks     force row level security;
alter table documents force row level security;
alter table cards     force row level security;
alter table reviews   force row level security;

create policy users_self on users
  using (id = app_user_id()) with check (id = app_user_id());

create policy decks_owner on decks
  using (user_id = app_user_id()) with check (user_id = app_user_id());

create policy documents_owner on documents
  using (user_id = app_user_id()) with check (user_id = app_user_id());

create policy cards_owner on cards
  using (user_id = app_user_id()) with check (user_id = app_user_id());

create policy reviews_owner on reviews
  using (user_id = app_user_id()) with check (user_id = app_user_id());

-- sessions, login_attempts are only touched by server-side auth code
-- using a privileged role; do NOT expose them to the per-request role.
